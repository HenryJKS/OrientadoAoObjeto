package br.fiap.controle;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import br.fiap.cliente.Cliente;
import br.fiap.empregado.gerente.Gerente;
import br.fiap.empregado.vendedor.Vendedor;
import br.fiap.pessoa.Pessoa;
import static javax.swing.JOptionPane.*;
import static java.lang.Integer.parseInt;
import static java.lang.Double.*;

public class Controle {

	private ArrayList<Pessoa> lista = new ArrayList<Pessoa>();
	
	// Menu Principal da aplica��o
	
	public void menuPrincipal() {
		int opcao = 0;
		String menu = "Escolha uma opc�o:\n";
		menu += "1. Cadastrar Empregado:\n";
		menu += "2. Cadastrar Cliente:\n";
		menu += "3. Pesquisar:\n";
		menu += "4. Listar Empregados:\n";
		menu += "5. Listar Cliente:\n";
		menu += "6. Remover:\n";
		menu += "7. Finalizar:\n";
		
		do {
			
			try {
				opcao = parseInt(showInputDialog(menu));
				if(opcao < 1 || opcao > 7) {
					showMessageDialog(null, "Opc�o Invalida");
				} else {
					switch(opcao) {
					case 1:
						cadastrarEmpregado();
					    break;
					case 2:
						cadastrarCliente();
					    break;
					case 3:
						pesquisar();
						break;
					case 4:
						listarEmpregado();
						break;
					case 5:
						listarCliente();
						break;	
					case 6:
						remover();
						break;
					}
				  } 
				}		   
			catch(NumberFormatException e) {
				showMessageDialog(null, "Voce deve digitar um NUMERO!!!");
			  }
			
			} while(opcao != 7);
			
	}      
	
	private void cadastrarEmpregado() {
		int opcao = 0;
		double salario, bonus;
		double totalDasVendas, comissao;
		String nome, cpf, matricula;
		String menu = "Escolha um opc�o\n";
		
		menu += "1. Gerente\n";
		menu += "2. Vendedor\n";
		menu += "3. Retornar\n";
		
		do {
			
			try {
				opcao = parseInt(showInputDialog(menu));
				if(opcao < 1 || opcao > 3) {
					showMessageDialog(null, "Opc�o Inv�lida");
				} else {
				  if(opcao == 1 || opcao == 2) {
					  nome = showInputDialog("Nome");
					  cpf = showInputDialog("CPF");
					  matricula = showInputDialog("Matricula");
					  if(opcao == 1) {
						  salario = parseDouble(showInputDialog("Salario"));
						  bonus = parseDouble(showInputDialog("B�nus em %"));
						  lista.add(new Gerente(nome, cpf, matricula, salario, bonus));
					  } else {
						  totalDasVendas = parseDouble(showInputDialog("Total das Vendas"));
						  comissao = parseDouble(showInputDialog("Comiss�o"));
						  lista.add(new Vendedor(nome, cpf, matricula, totalDasVendas, comissao));
						
					  }
				   }
		        }
		     }
			catch(NumberFormatException e) {
				showMessageDialog(null, "Voc� deve digitar uma op��o NUM�RICA !!" );
			}
			
		} while(opcao != 3);	
	}
	
	private void cadastrarCliente() {
		String nome, cpf;
		double valorDaDivida;
		
		nome = showInputDialog("Nome");
		cpf = showInputDialog("CPF");
		valorDaDivida = parseDouble(showInputDialog("Valor da divida"));
		lista.add(new Cliente(nome, cpf, valorDaDivida));
		
	}
	
	//Lista os empregados na lista
	private void listarEmpregado() {
		String gerente = "";
		String vendedor = "";
		
		for(Pessoa pessoa : lista) {
			if(pessoa instanceof Gerente) {
				gerente += pessoa + "\n"; //pessoa.toString();			
		   } else if(pessoa instanceof Vendedor) {
			   vendedor += pessoa + "\n"; //pessoa.toString();
		   }
		}
		
		showMessageDialog(null, gerente + "\n" + vendedor);
	 }
	
	private void listarCliente() {
		String cliente = "";
		
		for(Pessoa pessoa : lista) {
			if(pessoa instanceof Cliente) {
				cliente += pessoa + "\n";
			}
		}
		
		showMessageDialog(null, cliente);
	}
	
	private void pesquisar() {
		String aux = "";
		int indice = pesquisarAux();
		if(indice == -1) {
			showMessageDialog(null, "N�o Encontrado");
		 } else {
			if(lista.get(indice) instanceof Cliente) {
				aux += "Cliente:\n";
			  } else {
				aux += "Empregado:\n";
			}
		    aux += lista.get(indice);
		    showMessageDialog(null, aux);
		}
	}
	
	private int pesquisarAux() {
		int indice = -1;
		String cpf = showInputDialog("CPF Para Pesquisa");
		for(int i = 0; i < lista.size(); i++) {
			if(lista.get(i).getCpf().equals(cpf)) {
				indice = i;
			}
		}	
		return indice;
	}
	
	//metodo para remover uma pessoa pelo CPF
	private void remover() {
		int resposta;
		int indice = pesquisarAux();
		if(indice == -1) {
			showMessageDialog(null, "N�o Encontrado");
		   } else {
			   resposta = showConfirmDialog(null, "Deseja Exlcuir?!!");
			   if(resposta == 0) {
				   lista.remove(indice);
			   }
		}
	}
	
}
