package br.fiap.interfac;

import br.fiap.*;

public interface Salario {
	
	public double calcularSalario();
	

}
