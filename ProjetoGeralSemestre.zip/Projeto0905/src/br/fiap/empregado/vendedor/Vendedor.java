package br.fiap.empregado.vendedor;

import br.fiap.empregado.Empregado;
import br.fiap.interfac.Salario;

public class Vendedor extends Empregado implements Salario{
    private double totalDasVendas;
    private double comissao;
    
	public Vendedor(String nome, String cpf, String matricula, double totalDasVendas, double comissao) {
		super(nome, cpf, matricula);
		this.totalDasVendas = totalDasVendas;
		this.comissao = comissao;
	}
	
	public double calcularSalario() {
		return 0;
	}
	
	@Override
	public String toString() {
		String aux = "";
		aux += "Nome: " + nome + "\n";
		aux += "CPF: " + cpf + "\n";
		aux += "Total Das Vendas: " + totalDasVendas + "\n";	
		aux += "Comiss�o Em R$: " + comissao + "\n";
		return aux;
	}
	

    
   
    
    

}
