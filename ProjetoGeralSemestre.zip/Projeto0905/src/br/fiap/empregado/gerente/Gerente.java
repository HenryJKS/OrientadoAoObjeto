package br.fiap.empregado.gerente;

import br.fiap.empregado.Empregado;
import br.fiap.interfac.Bonus;

public class Gerente extends Empregado {
	private double salario;
	private double bonus;
	
	public Gerente(String nome, String cpf, String matricula, double salario, double bonus) {
		super(nome, cpf, matricula);
		this.salario = salario;
		this.bonus = bonus;
	}
	
	public double calcularBonus() {
		return 0;
	}
	
	@Override
	public String toString() {
		String aux = "";
		aux += "Nome: " + nome + "\n";
		aux += "CPF: " + cpf + "\n";
		aux += "Salario Em R$: " + salario + "\n";
		aux += "Bonus Em %: " + bonus + "\n";
		return aux;
	}
	
	
	
	
	

}
