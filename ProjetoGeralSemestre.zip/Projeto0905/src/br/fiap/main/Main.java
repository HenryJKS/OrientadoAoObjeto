package br.fiap.main;

import br.fiap.controle.Controle;

public class Main {
	public static void main(String[] args) {
		
		Controle controle = new Controle();
		controle.menuPrincipal();

	}

}
