package br.fiap.controle;

public class Controle {
	
	
	protected int indice;

}
