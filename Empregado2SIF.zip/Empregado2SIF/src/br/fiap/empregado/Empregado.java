package br.fiap.empregado;

public abstract class Empregado {
	
	protected long matricula;
	protected String nome;
	
	
//M�todo para calcular	
	public abstract double calcularSalario();

	
//M�todo Construtor
	
	public Empregado(long matricula, String nome) {
		super();
		this.matricula = matricula;
		this.nome = nome;
	}
	
	@Override
	public String toString() {
		String aux = "";
		aux += "Matricula: " + matricula + "\n";
		aux += "Nome: " + nome + "\n";
		return aux;
	}
	
	
	
	
	
}
