package br.fiap.main;

import br.fiap.empregado.Empregado;
import br.fiap.empregado.EmpregadoComissionado;
import br.fiap.empregado.EmpregadoHorista;

public class Main {

	public static void main(String[] args) {
		
		Empregado[] empregado = new Empregado[2];
		
		empregado[0] = new EmpregadoComissionado(1000, "Henry", 5000, 1000);
		empregado[1] = new EmpregadoHorista(2000, "Paulo", 10000, 2000);
				
		
		for(int i = 0; i < empregado.length; i++) {
			System.out.println(empregado[i]);
			System.out.println();
		}
		
	}

}
