package br.fiap.main;

import br.fiap.empregado.Empregado;

public class Main {

	public static void main(String[] args) {
		
		
		
	}

}
