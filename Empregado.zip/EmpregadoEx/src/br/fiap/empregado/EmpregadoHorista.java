package br.fiap.empregado;

public class EmpregadoHorista extends Empregado {

	//Atributos u�nicos
	private int totalDeHoraTrabalhadas;
	private double valorDaHoraTrabalhada;
	
	//M�todo para calcular sal�rio
	public double calculoSalario() {
		return (totalDeHoraTrabalhadas * valorDaHoraTrabalhada);
		
	}

	//M�todo Construtor
	public EmpregadoHorista(long matricula, String nome, int totalDeHoraTrabalhadas, double valorDaHoraTrabalhada) {
		super(matricula, nome);
		this.totalDeHoraTrabalhadas = totalDeHoraTrabalhadas;
		this.valorDaHoraTrabalhada = valorDaHoraTrabalhada;
	}

	
	
	
	
	
}
