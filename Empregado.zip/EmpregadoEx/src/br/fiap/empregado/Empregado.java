package br.fiap.empregado;

public abstract class Empregado {

	//Atributos compartilhados
	protected long matricula;
	protected String nome;
	
	//M�todo para calcular sal�rio
	public abstract double calculoSalario();

	//M�todo Construtor
	public Empregado(long matricula, String nome) {
		super();
		this.matricula = matricula;
		this.nome = nome;
	}
	
	@Override
	public String toString() {
	   String aux = "";
	   aux += "Matr�cula: " + matricula + "\n";
	   aux += "Nome: " + nome + "\n";
	   aux += "Calculo do Sal�rio: " + calculoSalario() + " R$";
	   return aux;
	}
	
	
	
}
