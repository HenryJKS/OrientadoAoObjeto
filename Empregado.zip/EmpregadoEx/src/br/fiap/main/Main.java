package br.fiap.main;

import br.fiap.empregado.Empregado;
import br.fiap.empregado.EmpregadoComissionado;
import br.fiap.empregado.EmpregadoHorista;

public class Main {

	public static void main(String[] args) {
		
		Empregado[] empregado = new Empregado[4];
		
		empregado[0] = new EmpregadoComissionado(1000, "Maria", 50, 20);
		empregado[1] = new EmpregadoHorista(2000, "Joao", 15, 50);
		empregado[2] = new EmpregadoComissionado(3000,"Matheus", 100, 20);
		empregado[3] = new EmpregadoHorista(4000, "Henry", 250, 10);
		
		for(int i = 0; i < empregado.length; i++) {
			System.out.println(empregado[i]);
			System.out.println();
		}
	
	
		
	
	   
		
		
			

	}
}
