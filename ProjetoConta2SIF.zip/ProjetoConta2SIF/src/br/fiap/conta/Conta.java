package br.fiap.conta;

import br.fiap.cliente.Cliente;

public class Conta {
	private Cliente cliente;
	private double saldo;
	
	public Conta(Cliente cliente, double saldo) {
		super();
		this.cliente = cliente;
		this.saldo = saldo;
	}

	public String getDados() {
		String aux = "";
		aux += "CPF: " + cliente.getCpf() + "\n";
		aux += "Nome: " + cliente.getNome() + "\n";
		aux += "Saldo R$ " + saldo;
		return aux;
	}
	
	public void sacar(double valor) {
		saldo -= valor;
		
	}
	
	public void depositar(double valor) {
		saldo += valor;
	}
	
	
	
	

}
