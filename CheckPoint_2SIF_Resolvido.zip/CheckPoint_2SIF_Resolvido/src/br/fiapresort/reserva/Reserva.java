package br.fiapresort.reserva;

import br.fiapresort.hospede.Hospede;
import br.fiapresort.hotel.Resort;

public class Reserva {

	private String data;
	private Resort resort;
	private Hospede hospede;
	
	public Reserva(String data, Resort resort, Hospede hospede) {
		super();
		this.data = data;
		this.resort = resort;
		this.hospede = hospede;
	}
	
	public Reserva(Resort resort, Hospede hospede) {
		super();
		this.data = "25/04/2022";
		this.resort = resort;
		this.hospede = hospede;
	}
	
	public String getDados() {
		String aux = "";
		aux += "Data: " + data + "\n";
		aux += resort.getDados();
		aux += hospede.getDados();
		return aux;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public Resort getResort() {
		return resort;
	}

	public void setResort(Resort resort) {
		this.resort = resort;
	}

	public Hospede getHospede() {
		return hospede;
	}

	public void setHospede(Hospede hospede) {
		this.hospede = hospede;
	}
	
	
	
	
	
	
}
