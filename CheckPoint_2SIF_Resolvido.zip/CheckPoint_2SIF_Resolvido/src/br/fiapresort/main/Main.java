package br.fiapresort.main;

import br.fiapresort.hospede.Hospede;
import br.fiapresort.hotel.Resort;
import br.fiapresort.reserva.Reserva;

public class Main {

	public static void main(String[] args) {
		
		// Array para armazenar objeto Reserva
		Reserva[] reserva = new Reserva[4];
		
		Hospede h1 = new Hospede("123", "Jo�o");
		Hospede h2 = new Hospede("456", "Maria");
		Hospede h3 = new Hospede("789", "Ana");
		Hospede h4 = new Hospede("101112", "Pedro");
		
		
	    Resort r1 = new Resort("S�o Paulo", 5, "999");
	    Resort r2 = new Resort("Rio de Janeiro", 3, "888");
	    Resort r3 = new Resort("Fortaleza", 4, "777");
	    Resort r4 = new Resort("Cear�", 5, "666");
	    
	    //Ex 4
	    reserva[0] = new Reserva(r1, h1);
	    reserva[1] = new Reserva("07/05/2022", r2, h2);
	    reserva[2] = new Reserva(r1, h3);
	    reserva[3] = new Reserva("01/07/2022", r2, h4);
	    
	    //Ex 5
	    for(int i = 0; i < reserva.length; i++) {
	    	System.out.println(reserva[i].getDados());
	    }
	    
	    //Ex 6
	        System.out.println("Reservado em SP 25/04/2022");
	        System.out.println("");
	    for(int i = 0; i < reserva.length; i++) {
	    	if(reserva[i].getResort().getCidade().equals("S�o Paulo") && reserva[i].getData().equals("25/04/2022"));
	    	System.out.println(reserva[i].getDados());
	    }
	    

	}


}
