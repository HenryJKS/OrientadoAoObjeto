package br.fiapresort.hotel;

public class Resort {

	private String cidade;
	private int categoria;
	private String fone;
	
	public Resort(String cidade, int categoria, String fone) {
		super();
		this.cidade = cidade;
		this.categoria = categoria;
		this.fone = fone;
	}
	
	public String getDados() {
		String aux = "";
		aux += "Cidade: " + cidade + "\n";
		aux += "Categoria: " + categoria + "\n";
		aux += "Telefone: " + fone + "\n";
		return aux;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public int getCategoria() {
		return categoria;
	}

	public void setCategoria(int categoria) {
		this.categoria = categoria;
	}

	public String getFone() {
		return fone;
	}

	public void setFone(String fone) {
		this.fone = fone;
	}
	
	
	
	
	
}
