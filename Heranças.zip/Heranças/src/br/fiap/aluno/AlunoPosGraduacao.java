package br.fiap.aluno;

public class AlunoPosGraduacao extends Aluno {
	
	//metodo para calcular e retornar a m�dia
	
		public double calcularMedia() {
			
		}
		
}
