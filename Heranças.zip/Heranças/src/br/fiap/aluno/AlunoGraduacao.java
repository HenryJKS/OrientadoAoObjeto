package br.fiap.aluno;

public class AlunoGraduacao extends Aluno {
	
	//Atributos �nico
	
	private String curso;
	private double trabalho;

	//metodo para calcular e retornar a m�dia
	
	public double calcularMedia() {
		return(prova1 + prova2) / 2 * 0.7 + trabalho * 0.3;
		
	}

	//M�todo Construtor
	
	public AlunoGraduacao(long rm, String nome, double prova1, double prova2, String curso, double trabalho) {
		super(rm, nome, prova1, prova2);
		this.curso = curso;
		this.trabalho = trabalho;
	}
	
	
	}
