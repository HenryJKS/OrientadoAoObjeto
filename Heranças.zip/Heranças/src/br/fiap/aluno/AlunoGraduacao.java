package br.fiap.aluno;

public class AlunoGraduacao extends Aluno {
	
	//Atributos �nico
	
	private String curso;
	private double trabalho;

	//metodo para calcular e retornar a m�dia
	
	public double calcularMedia() {
		
	}
	
	
	}
