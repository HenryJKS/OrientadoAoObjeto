package br.fiap.aluno;

public class AlunoFundamental extends Aluno{
	
    //Atributo especifico da classe
	
	private int serie;
	
	//metodo para calcular e retornar a m�dia
	
		public double calcularMedia() {
			return(prova1 + prova2) / 2;
		}

		
    //M�todo Construtor
	public AlunoFundamental(long rm, String nome, double prova1, double prova2, int serie) {
		super(rm, nome, prova1, prova2);
		this.serie = serie;
	}
	

		
}
