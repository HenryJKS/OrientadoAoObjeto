package br.fiap.aluno;

public abstract class Aluno {
	
	// Atributos em comum compartilhados

	protected long rm;
	protected String nome;
	protected double prova1;
	protected double prova2;
	
	
	

	
	
	
}
