package br.fiap.aluno;

public abstract class Aluno {
	
	// Atributos em comum compartilhados

	protected long rm;
	protected String nome;
	protected double prova1;
	protected double prova2;
	
	
	// M�todo para calcular e retornar a m�dia
	public abstract double calcularMedia();


	//M�todo Construtor
	public Aluno(long rm, String nome, double prova1, double prova2) {
		super();
		this.rm = rm;
		this.nome = nome;
		this.prova1 = prova1;
		this.prova2 = prova2;
	}
	
	@Override
	public String toString() {
		String aux = "";
		aux += "RM: " + rm + "\n";
		aux += "Nome: " + nome + "\n";
		aux += "Prova1: " + prova1 + "\n";
		aux += "Prova2: " + prova2 + "\n";
		aux += "M�dia: " + calcularMedia();
		return aux;
	}
	

	
	
	
}
