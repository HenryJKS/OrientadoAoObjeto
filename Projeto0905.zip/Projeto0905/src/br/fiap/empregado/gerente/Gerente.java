package br.fiap.empregado.gerente;

import br.fiap.empregado.Empregado;
import br.fiap.interfac.Bonus;

public abstract class Gerente extends Empregado {
	private double salario;
	private double bonus;
	
	public Gerente(String nome, String cpf, String matricula, double salario, double bonus) {
		super(nome, cpf, matricula);
		this.salario = salario;
		this.bonus = bonus;
	}
	
	public abstract double calcularBonus();
	
	
	
	
	

}
