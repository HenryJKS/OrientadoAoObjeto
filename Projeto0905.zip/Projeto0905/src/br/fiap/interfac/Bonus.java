package br.fiap.interfac;
import br.fiap.*;

public interface Bonus {
	
	public double calcularBonus();

}
