package ClasseVol;

public interface Volume {

	public abstract double calcularVolume();
	
	
}
