package SubC;

import SuperC.Figura;

public class Circulo extends Figura {

	public Circulo(int coordenadaX, int coordenadaY, double raio) {
		super(coordenadaX, coordenadaY, raio);
	
	}
	
public double calcularArea() {
	//(raio * raio) * 3.14;
	return 0;
}
	
	

}
