package SubC2;

import ClasseVol.Volume;
import SuperC.Figura;

public class Cilindro extends Figura implements Volume {
	
   private double altura;

public Cilindro(int coordenadaX, int coordenadaY, double raio, double altura) {
	super(coordenadaX, coordenadaY, raio);
}

	public double calcularArea() {
		return 0;
	}
	
    public double calcularVolume() {
	    return 0; 
    }

	

   
   
}
