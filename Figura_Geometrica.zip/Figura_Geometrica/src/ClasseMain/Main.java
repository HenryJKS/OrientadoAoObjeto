package ClasseMain;

import ClasseVol.Volume;
import SubC.Circulo;
import SubC2.Cilindro;
import SuperC.Figura;


public class Main {

	public static void main(String[] args) {
	
		Figura[] figura = new Figura[4];	
		figura[0] = new Circulo(10, 20, 40);
		figura[1] = new Circulo(30, 50, 70);
		figura[2] = new Cilindro(2, 5, 10, 15);
		figura[3] = new Cilindro(10, 20, 30, 40);
		
		//Imprimir a area de cada objeto
		for(Figura f : figura) {
			System.out.println(f.calcularArea());
		}
		
		//Imprimir o volume de cada objeto
		System.out.println();
		for(Figura f : figura) {
			if(f instanceof Volume) {
				System.out.println(((Volume) f).calcularVolume());
			}
		}
		

		
		
		
		
	}

}
