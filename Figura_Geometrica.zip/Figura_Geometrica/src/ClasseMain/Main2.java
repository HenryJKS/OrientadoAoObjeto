package ClasseMain;

import java.util.ArrayList;

import ClasseVol.Volume;
import SubC.Circulo;
import SubC2.Cilindro;
import SuperC.Figura;

public class Main2 {

	public static void main(String[] args) {
		
		ArrayList<Figura> lista = new ArrayList<Figura>();
		lista.add(new Circulo(2, 2, 2));
		lista.add(new Cilindro(3, 3, 3, 3));
		lista.add(new Circulo(4, 4, 4));
		lista.add(new Cilindro(5, 5, 5, 5));
		
		//Impress�o dos elementos do array
		Figura aux;
		for(int i = 0; i < lista.size(); i++) {
			aux = lista.get(i);
			System.out.println(aux);
			System.out.println();
		}
		
		//Impress�o da �rea e volume de cada projeto
		for(Figura f : lista) {
			System.out.println("�rea: " + f.calcularArea());
			if(f instanceof Volume) {
			System.out.println("Volume: " + ((Volume)f).calcularVolume());
			}
		}
		
	
	}

}
