
import java.util.Scanner;

import filas.FilaString;

public class ConsultorioNome {

	public static void main(String[] args) {
	
		Scanner le = new Scanner(System.in);
		FilaString filas = new FilaString();
		
		filas.init();
		//criar fila com nomes
		
		int op;
		do {
			System.out.println("1- Insere paciente na fila");
			System.out.println("2- Chama paciente para o atendimento");
			System.out.println("3- Encerra o atendimento do dia");
			System.out.println("   Op��o:   ");
			op = le.nextInt();
			switch (op) {
			case 1:
				System.out.println("Nome do paciente: ");
				String nome = le.next();
				//insere paciente na fila
				filas.enqueue(nome);
				break;
			case 2:
				//retira o paciente da fila e apresenta seu nome
				if (!filas.isEmpty())
					System.out.println("Paciente sendo chamado para atendimento " + filas.dequeue());
				break;
			case 3:
				if(!filas.isEmpty()) {
					System.out.println("H� pacientes em espera ");
					op = 0;
				}
				break;
			default:
				System.out.println("Op��o Inv�lida");
			}
		} while(op!=3);
		le.close();
		System.out.println("Atendimento encerrado!");
	}

}
